# multiple_disease_prediction
Multiple Disease Prediction System
